
import numpy as np

def region_features(rgb,boxes,bins=16):
    rgb=np.asarray(rgb)
    if rgb.dtype!=np.uint8 or rgb.ndim!=3 or rgb.shape[2]!=3: raise ValueError('expected uint8 RGB')
    features=[]
    for x,y,w,h in boxes:
        if min(x,y)<0 or min(w,h)<1 or x+w>rgb.shape[1] or y+h>rgb.shape[0]: raise ValueError('invalid xywh box')
        patch=rgb[y:y+h,x:x+w]
        hist=np.concatenate([np.histogram(patch[...,c],bins=bins,range=(0,256))[0] for c in range(3)]).astype(float)
        features.append(hist/(w*h))
    return np.asarray(features).reshape(-1,3*bins)

def train_svm(features,labels,path):
    
    from sklearn.svm import LinearSVC
    x=np.asarray(features,dtype=float); y=np.asarray(labels)
    if x.ndim!=2 or x.shape[1]!=48 or y.shape!=(len(x),) or set(np.unique(y))!={0,1}:
        raise ValueError('need [N,48] features and binary labels containing both classes')
    svm=LinearSVC(C=1.,random_state=7).fit(x,y)
    with open(path,'wb') as f: np.savez(f,weight=svm.coef_[0],bias=svm.intercept_[0])

def propose_faces(rgb,svm_path,threshold=0.,max_proposals=2000):
    import cv2
    if not hasattr(cv2,'ximgproc') or not hasattr(cv2.ximgproc,'segmentation'):
        raise RuntimeError('selective search requires opencv-contrib-python')
    if max_proposals<1: raise ValueError('max_proposals must be positive')
    search=cv2.ximgproc.segmentation.createSelectiveSearchSegmentation()
    search.setBaseImage(np.ascontiguousarray(rgb[...,::-1])); search.switchToSelectiveSearchFast()
    boxes=np.asarray(search.process()[:max_proposals],dtype=int).reshape(-1,4)
    with np.load(svm_path,allow_pickle=False) as z: weight=z['weight']; bias=float(z['bias'])
    if weight.shape!=(48,) or not np.isfinite(weight).all() or not np.isfinite(bias): raise ValueError('invalid SVM')
    scores=region_features(rgb,boxes)@weight+bias
    keep=np.flatnonzero(scores>=threshold); keep=keep[np.argsort(-scores[keep],kind='stable')]
    return boxes[keep],scores[keep]
