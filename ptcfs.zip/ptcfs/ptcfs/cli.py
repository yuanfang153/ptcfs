"""Reproducible CLI. Training/validation split manifests must be supplied."""
import argparse
from dataclasses import asdict
import json
import math
from pathlib import Path
import random
import numpy as np
from PIL import Image,ImageDraw
import torch
from torch.utils.data import DataLoader
from .model import ModelConfig,PTCFSReference,ptcfs_loss
from .data import CLASS_NAMES,PatchDataset,read_manifest,read_image,read_mask,confusion_matrix,metric_report
from .pipeline import build_bank,load_bank,predict_image,tiles
from .skm import SKMConfig


def seed_everything(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark=False
    torch.use_deterministic_algorithms(True,warn_only=True)

def load_checkpoint(path,device):
    ckpt=torch.load(path,map_location=device,weights_only=True)
    if ckpt.get('format')!=1: raise ValueError('unsupported checkpoint')
    model=PTCFSReference(ModelConfig(**ckpt['config'])).to(device)
    model.load_state_dict(ckpt['model'],strict=True); model.eval()
    return model,ckpt

def save_checkpoint(path,model,optimizer,epoch,step,seed,validation):
    torch.save(dict(format=1,config=asdict(model.config),model=model.state_dict(),
                    optimizer=optimizer.state_dict(),epoch=epoch,step=step,seed=seed,
                    inference_phase='sigmoid',validation=validation),path)

def evaluate_rows(model,rows,stride,batch,phase,step,bank=None):
    cm=np.zeros((model.config.num_classes,)*2,np.int64); diagnostics=[]
    for row in rows:
        image=read_image(row['image']); truth=read_mask(row['mask'],image.shape[:2],model.config.num_classes)
        pred,_,info=predict_image(model,image,bank,stride,batch,phase,step)
        cm+=confusion_matrix(truth,pred,model.config.num_classes); diagnostics.append(info)
    return dict(metrics=metric_report(cm),confusion_matrix=cm.tolist(),diagnostics=diagnostics)

def train(args):
    if min(args.epochs,args.batch_size,args.samples_per_image,args.stride)<1: raise ValueError('sizes must be positive')
    if args.lr<=0 or args.weight_decay<0 or args.warmup_steps<0: raise ValueError('invalid optimizer arguments')
    seed_everything(args.seed)
    train_rows=read_manifest(args.train); val_rows=read_manifest(args.val)
    if {r['image'] for r in train_rows}&{r['image'] for r in val_rows}: raise ValueError('training/validation image leakage')
    out=Path(args.output); out.mkdir(parents=True,exist_ok=True)
    cfg=ModelConfig(num_classes=args.classes,mode=args.mode)
    model=PTCFSReference(cfg).to(args.device)
    dataset=PatchDataset(train_rows,args.classes,cfg.patch_size,args.samples_per_image,args.seed,True)
    loader=DataLoader(dataset,batch_size=args.batch_size,shuffle=True,num_workers=0,
                      generator=torch.Generator().manual_seed(args.seed))
    if len(loader)<2: raise ValueError('at least two batches are needed for the two-phase epoch')
    optimizer=torch.optim.AdamW(model.parameters(),lr=args.lr,weight_decay=args.weight_decay,betas=(.9,.999))
    total=args.epochs*len(loader); warm=min(args.warmup_steps,total-1); step=0; best=-1.; history=[]
    for epoch in range(args.epochs):
        model.train(); dataset.epoch=epoch; running=0.
        for bi,(image,label) in enumerate(loader):
            factor=((step+1)/warm if warm and step<warm else
                    .5*(1+math.cos(math.pi*(step-warm)/max(total-warm-1,1))))
            for group in optimizer.param_groups: group['lr']=args.lr*factor
            phase='compress' if bi<len(loader)/2 else 'sigmoid'
            optimizer.zero_grad(set_to_none=True)
            loss=ptcfs_loss(model(image.to(args.device),phase,step),label.to(args.device))['loss']
            if not torch.isfinite(loss): raise FloatingPointError(f'nonfinite loss at step {step}')
            loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),5.,error_if_nonfinite=True)
            optimizer.step(); running+=float(loss.detach()); step+=1
        # Explicit DRFE-only validation, not a claim of full PTCFS paper reproduction.
        validation=evaluate_rows(model,val_rows,args.stride,args.batch_size,'sigmoid',step)
        score=validation['metrics']['foreground_f1']
        if score is None: score=validation['metrics']['macro_f1']
        record=dict(epoch=epoch+1,train_loss=running/len(loader),validation=validation,
                    selection='DRFE-only validation foreground F1; macro F1 if no foreground denominator')
        history.append(record)
        save_checkpoint(out/'last.pt',model,optimizer,epoch,step,args.seed,validation)
        if score is not None and score>best:
            best=score; save_checkpoint(out/'best.pt',model,optimizer,epoch,step,args.seed,validation)
        (out/'history.json').write_text(json.dumps(history,indent=2,allow_nan=False),encoding='utf-8')
        print(json.dumps(dict(epoch=epoch+1,loss=record['train_loss'],validation_f1=score)),flush=True)
    (out/'run_config.json').write_text(json.dumps(vars(args),indent=2),encoding='utf-8')

def tile_dataset(args):
    rows=read_manifest(args.manifest); out=Path(args.output).resolve(); out.mkdir(parents=True,exist_ok=True)
    result=[]
    for i,row in enumerate(rows):
        image=read_image(row['image']); mask=read_mask(row['mask'],image.shape[:2],args.classes)
        for y,x,tile in tiles(image):
            stem=f'{i:06d}_{y}_{x}'; ip=out/(stem+'.png'); mp=out/(stem+'_mask.png')
            Image.fromarray(np.rint(tile*255).astype(np.uint8)).save(ip)
            h,w=tile.shape[:2]; Image.fromarray(mask[y:y+h,x:x+w].astype(np.uint8)).save(mp)
            result.append(dict(image=ip.name,mask=mp.name))
    (out/'manifest.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(f'Created {len(result)} tiles. Split by source animal/session BEFORE tiling.')

def make_demo(args):
    """Synthetic shapes only; no claimed cattle validation or trained weights."""
    out=Path(args.output).resolve(); out.mkdir(parents=True,exist_ok=True); rng=np.random.default_rng(7)
    for split,n in [('train',4),('val',2),('test',2)]:
        rows=[]
        for i in range(n):
            im=Image.new('RGB',(64,64),(20,25,30)); mask=Image.new('L',(64,64),0)
            d=ImageDraw.Draw(im); m=ImageDraw.Draw(mask); shift=int(rng.integers(-5,6))
            box=(8+shift,10,34+shift,52); d.ellipse(box,fill=(220,65,45)); m.ellipse(box,fill=1)
            box=(36+shift,18,56+shift,45); d.rectangle(box,fill=(50,200,90)); m.rectangle(box,fill=2)
            ip=out/f'{split}_{i}.png'; mp=out/f'{split}_{i}_mask.png'; im.save(ip); mask.save(mp)
            rows.append(dict(image=ip.name,mask=mp.name))
        (out/f'{split}.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    print('Synthetic three-class data created; use --classes 3 for training.')

def main():
    parser=argparse.ArgumentParser(description='PTCFS research reconstruction, not an exact reproduction')
    sub=parser.add_subparsers(dest='command',required=True)
    p=sub.add_parser('train'); p.add_argument('--train',required=True); p.add_argument('--val',required=True)
    p.add_argument('--output',required=True); p.add_argument('--classes',type=int,default=10)
    p.add_argument('--epochs',type=int,default=50); p.add_argument('--samples-per-image',type=int,default=128)
    p.add_argument('--lr',type=float,default=5e-4); p.add_argument('--weight-decay',type=float,default=1e-4)
    p.add_argument('--warmup-steps',type=int,default=100); p.add_argument('--seed',type=int,default=7)
    p.add_argument('--mode',choices=['stabilized','literal'],default='stabilized')
    p.add_argument('--stride',type=int,default=4); p.add_argument('--batch-size',type=int,default=32)
    p.add_argument('--device',default='cpu')
    for name in ('build-bank','predict','evaluate'):
        p=sub.add_parser(name); p.add_argument('--checkpoint',required=True); p.add_argument('--output',required=True)
        p.add_argument('--device',default='cpu'); p.add_argument('--stride',type=int,default=4)
        p.add_argument('--batch-size',type=int,default=64)
        if name=='build-bank': p.add_argument('--references',required=True)
        else:
            p.add_argument('--bank'); p.add_argument('--drfe-only',action='store_true')
            if name=='predict':
                p.add_argument('--image',required=True); p.add_argument('--fallback',choices=['capsule','unknown'],default='capsule')
                p.add_argument('--roi',nargs=4,type=int,metavar=('X','Y','W','H'))
            else: p.add_argument('--manifest',required=True)
    p=sub.add_parser('tile-data'); p.add_argument('--manifest',required=True); p.add_argument('--output',required=True)
    p.add_argument('--classes',type=int,default=10)
    p=sub.add_parser('make-demo'); p.add_argument('--output',required=True)
    args=parser.parse_args()
    if args.command=='train': return train(args)
    if args.command=='tile-data': return tile_dataset(args)
    if args.command=='make-demo': return make_demo(args)
    model,checkpoint=load_checkpoint(args.checkpoint,args.device)
    phase=checkpoint['inference_phase']; step=checkpoint['step']
    if args.command=='build-bank':
        print(json.dumps(build_bank(model,read_manifest(args.references),args.output,args.stride,args.batch_size,phase,step)))
        return
    if bool(args.bank)==bool(args.drfe_only): raise ValueError('choose exactly one of --bank or --drfe-only')
    bank=load_bank(args.bank,model,args.stride,phase,step) if args.bank else None
    output=Path(args.output); output.parent.mkdir(parents=True,exist_ok=True)
    if args.command=='evaluate':
        rows=read_manifest(args.manifest)
        if bank and {str(r['image']) for r in rows}&set(bank['metadata']['source_images']):
            raise ValueError('evaluation/reference image leakage')
        report=evaluate_rows(model,rows,args.stride,args.batch_size,phase,step,bank)
        output.write_text(json.dumps(report,indent=2,allow_nan=False),encoding='utf-8'); print(json.dumps(report['metrics']))
    else:
        image=read_image(args.image); roi=args.roi
        if roi:
            x,y,w,h=roi
            if min(x,y)<0 or min(w,h)<1 or x+w>image.shape[1] or y+h>image.shape[0]: raise ValueError('ROI outside image')
            tile=image[y:y+h,x:x+w]
        else: tile=image
        pred,_,info=predict_image(model,tile,bank,args.stride,args.batch_size,phase,step,fallback=args.fallback)
        if roi:
            full=np.full(image.shape[:2],-1,dtype=np.int64); full[y:y+h,x:x+w]=pred; pred=full
            info['roi_xywh']=roi; info['outside_roi']='unknown'
        if model.config.num_classes>255: raise ValueError('PNG output supports at most 255 classes')
        Image.fromarray(np.where(pred<0,255,pred).astype(np.uint8)).save(output)
        output.with_suffix('.json').write_text(json.dumps(info,indent=2),encoding='utf-8'); print(json.dumps(info))

if __name__=='__main__': main()
