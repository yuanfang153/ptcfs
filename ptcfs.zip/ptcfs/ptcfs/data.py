import json
from pathlib import Path
import numpy as np
from PIL import Image
import torch
from torch.utils.data import Dataset

CLASS_NAMES=('background','left_horn','right_horn','left_ear','right_ear',
             'left_eye','right_eye','nose','mouth','cheek')
IGNORE=255

def read_image(path):
    with Image.open(path) as im: return np.asarray(im.convert('RGB'),dtype=np.float32)/255.

def read_mask(path,shape,num_classes):
    with Image.open(path) as im: mask=np.asarray(im)
    if mask.ndim!=2 or mask.shape!=shape: raise ValueError(f'{path}: expected aligned indexed mask {shape}')
    if not np.issubdtype(mask.dtype,np.integer): raise ValueError('mask must contain integer IDs')
    if np.any((mask!=IGNORE)&((mask<0)|(mask>=num_classes))): raise ValueError(f'{path}: invalid class ID')
    return mask.astype(np.int64)

def read_manifest(path):
  
    path=Path(path).resolve(); rows=json.loads(path.read_text(encoding='utf-8-sig'))
    if not isinstance(rows,list) or not rows: raise ValueError('manifest must be a nonempty JSON list')
    result=[]
    for row in rows:
        if not isinstance(row,dict) or set(row)!={'image','mask'}: raise ValueError('each row needs image and mask only')
        item={k:(path.parent/row[k]).resolve() for k in ('image','mask')}
        if not all(p.is_file() for p in item.values()): raise ValueError(f'missing manifest file: {item}')
        result.append(item)
    if len({r['image'] for r in result})!=len(result): raise ValueError('duplicate images in manifest')
    return result

def crop_patch(image,y,x,size):
    
    before=size//2; after=size-1-before
    padded=np.pad(image,((before,after),(before,after),(0,0)),mode='edge')
    return padded[y:y+size,x:x+size].copy()

class PatchDataset(Dataset):
  
    def __init__(self,rows,classes=10,size=28,samples_per_image=128,seed=7,augment=False):
        if samples_per_image<1: raise ValueError('samples_per_image must be positive')
        self.rows=rows; self.classes=classes; self.size=size; self.count=samples_per_image
        self.seed=seed; self.epoch=0; self.augment=augment; self.cache={}
    def __len__(self): return len(self.rows)*self.count
    def __getitem__(self,index):
        i=index//self.count
        if i not in self.cache:
            image=read_image(self.rows[i]['image']); mask=read_mask(self.rows[i]['mask'],image.shape[:2],self.classes)
            present=np.unique(mask[mask!=IGNORE])
            if not len(present): raise ValueError('mask contains only ignore pixels')
            locations={int(c):np.argwhere(mask==c) for c in present}
            self.cache[i]=(image,mask,present,locations)
        image,mask,present,locations=self.cache[i]
        rng=np.random.default_rng(np.random.SeedSequence([self.seed,self.epoch,index]))
        label=int(rng.choice(present)); coords=locations[label]; y,x=coords[rng.integers(len(coords))]
        patch=crop_patch(image,int(y),int(x),self.size)
        if self.augment:
            # No left/right flips: anatomical-side convention is unspecified.
            patch=np.clip(patch*rng.uniform(.8,1.2)+rng.normal(0,.02,patch.shape),0,1).astype(np.float32)
        return torch.from_numpy(patch.transpose(2,0,1).copy()),torch.tensor(label,dtype=torch.long)

def confusion_matrix(truth,prediction,classes):
    truth=np.asarray(truth); prediction=np.asarray(prediction)
    if truth.shape!=prediction.shape: raise ValueError('mask shapes differ')
    if not np.issubdtype(truth.dtype,np.integer) or not np.issubdtype(prediction.dtype,np.integer):
        raise ValueError('metrics require integer masks')
    valid=truth!=IGNORE
    # Predicted ignore/unknown pixels at valid targets are not silently discarded.
    if np.any((truth[valid]<0)|(truth[valid]>=classes)) or np.any((prediction[valid]<0)|(prediction[valid]>=classes)):
        raise ValueError('invalid metric labels; resolve unknown predictions explicitly')
    return np.bincount(classes*truth[valid]+prediction[valid],minlength=classes**2).reshape(classes,classes)

def metric_report(cm):
    cm=np.asarray(cm,dtype=float)
    if cm.ndim!=2 or cm.shape[0]!=cm.shape[1] or (cm<0).any(): raise ValueError('invalid confusion matrix')
    tp=np.diag(cm); actual=cm.sum(1); predicted=cm.sum(0)
    def divide(a,b): return np.divide(a,b,out=np.full_like(a,np.nan,dtype=float),where=b>0)
    p=divide(tp,predicted); r=divide(tp,actual); f=divide(2*tp,actual+predicted); iou=divide(tp,actual+predicted-tp)
    # Binary foreground includes organ-to-organ confusions as foreground TP.
    fg_tp=cm[1:,1:].sum(); fp=cm[0,1:].sum(); fn=cm[1:,0].sum(); den=2*fg_tp+fp+fn
    def serial(a): return [None if not np.isfinite(v) else float(v) for v in a]
    finite=f[np.isfinite(f)]
    return dict(precision=serial(p),recall=serial(r),f1=serial(f),iou=serial(iou),
                macro_f1=float(finite.mean()) if len(finite) else None,
                foreground_f1=float(2*fg_tp/den) if den else None,pixels=int(cm.sum()))
