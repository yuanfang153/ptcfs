
from dataclasses import asdict
import hashlib
import json
import math
from pathlib import Path
import numpy as np
from scipy import ndimage as ndi
import torch
from .data import crop_patch,read_image,read_mask,IGNORE
from .skm import SKMConfig,detect_and_describe,match_descriptors,transfer_labels


def model_fingerprint(model):
    h=hashlib.sha256(json.dumps(asdict(model.config),sort_keys=True).encode())
    for name,t in sorted(model.state_dict().items()):
        h.update(name.encode()); h.update(t.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()

def tile_starts(length,tile=512,overlap=128):
    if length<1 or tile<1 or overlap<0 or overlap>=tile: raise ValueError('invalid tiling parameters')
    if length<=tile: return [0]
    starts=list(range(0,length-tile+1,tile-overlap))
    if starts[-1]!=length-tile: starts.append(length-tile)
    return starts

def tiles(image,tile=512,overlap=128):
    for y in tile_starts(image.shape[0],tile,overlap):
        for x in tile_starts(image.shape[1],tile,overlap):
            yield y,x,image[y:y+tile,x:x+tile]

@torch.inference_mode()
def dense_features(model,image,stride=4,batch_size=64,phase='sigmoid',step=0):
    if stride<1 or batch_size<1: raise ValueError('stride and batch_size must be positive')
    image=np.asarray(image,dtype=np.float32)
    if image.ndim!=3 or image.shape[2]!=3 or min(image.shape[:2])<1 or not np.isfinite(image).all():
        raise ValueError('expected finite RGB [H,W,3]')
    if image.min()<0 or image.max()>1: raise ValueError('image must be in [0,1]')
    h,w=image.shape[:2]
    ys=np.unique(np.rint(np.linspace(0,h-1,max(1,math.ceil(h/stride)))).astype(int))
    xs=np.unique(np.rint(np.linspace(0,w-1,max(1,math.ceil(w/stride)))).astype(int))
    positions=[(int(y),int(x)) for y in ys for x in xs]
    scores=[]; surfaces=[]; device=next(model.parameters()).device
    was_training=model.training; model.eval()
    try:
        for start in range(0,len(positions),batch_size):
            patches=np.stack([crop_patch(image,y,x,model.config.patch_size) for y,x in positions[start:start+batch_size]])
            output=model(torch.from_numpy(patches.transpose(0,3,1,2)).to(device),phase,step,False)
            scores.append(output['scores'].cpu().numpy())
            # Three lane magnitudes -> a spatial lattice. This placement is an assumption.
            surfaces.append(output['features'].norm(dim=-1).cpu().numpy())
    finally: model.train(was_training)
    scores=np.concatenate(scores).reshape(len(ys),len(xs),-1).transpose(2,0,1)
    surface=np.concatenate(surfaces).reshape(len(ys),len(xs),3).transpose(2,0,1)
    # Normalize capsule lengths to scores summing to one; not calibrated probabilities.
    denom=scores.sum(0,keepdims=True)
    scores=np.divide(scores,denom,out=np.full_like(scores,1/model.config.num_classes),where=denom>1e-12)
    return scores,surface,ys,xs

def rasterize(array,ys,xs,shape):
    
    gy=np.interp(np.arange(shape[0]),ys,np.arange(len(ys)))
    gx=np.interp(np.arange(shape[1]),xs,np.arange(len(xs)))
    yy,xx=np.meshgrid(gy,gx,indexing='ij')
    return np.stack([ndi.map_coordinates(a,[yy,xx],order=1,mode='nearest') for a in array]).astype(np.float32)

def bank_metadata(model,stride,phase,step,config):
    return dict(format=1,fingerprint=model_fingerprint(model),stride=stride,phase=phase,step=step,
                skm=asdict(config),classes=model.config.num_classes)

def build_bank(model,rows,path,stride=4,batch_size=64,phase='sigmoid',step=0,config=None):
    cfg=config or SKMConfig(); desc=[]; labels=[]; sources=[]
    for row in rows:
        image=read_image(row['image']); mask=read_mask(row['mask'],image.shape[:2],model.config.num_classes)
        for y,x,tile in tiles(image):
            _,surface,ys,xs=dense_features(model,tile,stride,batch_size,phase,step)
            kp=detect_and_describe(surface,cfg)
            if not len(kp.yx): continue
            py=np.rint(np.interp(kp.yx[:,0],np.arange(len(ys)),ys)).astype(int)+y
            px=np.rint(np.interp(kp.yx[:,1],np.arange(len(xs)),xs)).astype(int)+x
            ids=mask[py,px]; valid=ids!=IGNORE
            desc.extend(kp.descriptors[valid]); labels.extend(ids[valid]); sources.extend([str(row['image'])]*int(valid.sum()))
    if not desc: raise ValueError('No usable reference keypoints. Check training, texture, stride, and SKM detector thresholds.')
    meta=bank_metadata(model,stride,phase,step,cfg)
    meta['source_images']=sorted(set(sources))
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    # File object prevents numpy from silently appending an extension.
    with path.open('wb') as f:
        np.savez_compressed(f,descriptors=np.asarray(desc,np.float32),labels=np.asarray(labels,np.int64),metadata=json.dumps(meta))
    return dict(descriptors=len(desc),classes=sorted(set(map(int,labels))))

def load_bank(path,model,stride,phase,step,config=None):
    cfg=config or SKMConfig()
    with np.load(path,allow_pickle=False) as z:
        desc=z['descriptors'].copy(); labels=z['labels'].copy(); meta=json.loads(str(z['metadata']))
    expected=bank_metadata(model,stride,phase,step,cfg)
    # JSON converts scale tuples to lists; compare serialized forms canonically.
    for key,value in expected.items():
        if json.dumps(meta.get(key),sort_keys=True)!=json.dumps(value,sort_keys=True):
            raise ValueError(f'reference bank mismatch: {key}; rebuild with this model/config')
    if desc.ndim!=2 or desc.shape[1]!=384 or not len(desc) or labels.shape!=(len(desc),): raise ValueError('invalid bank dimensions')
    if not np.isfinite(desc).all() or (desc<0).any(): raise ValueError('invalid descriptors')
    if not np.issubdtype(labels.dtype,np.integer) or (labels<0).any() or (labels>=model.config.num_classes).any():
        raise ValueError('invalid bank labels')
    return dict(descriptors=desc,labels=labels,metadata=meta)

def predict_image(model,image,bank=None,stride=4,batch_size=64,phase='sigmoid',step=0,
                  config=None,tile_size=512,overlap=128,fallback='capsule'):
    
    cfg=config or SKMConfig()
    if fallback not in ('capsule','unknown'): raise ValueError('invalid fallback')
    image=np.asarray(image,dtype=np.float32); h,w=image.shape[:2]; classes=model.config.num_classes
    accum=np.zeros((classes,h,w),np.float32); weight=np.zeros((h,w),np.float32)
    covered=np.zeros((h,w),np.float32); count=np.zeros((h,w),np.float32)
    diagnostics=dict(tiles=0,keypoints=0,matches=0,drfe_only=bank is None,fallback=fallback)
    for y,x,tile in tiles(image,tile_size,overlap):
        score,surface,ys,xs=dense_features(model,tile,stride,batch_size,phase,step)
        matched=np.zeros(surface.shape[1:],bool)
        if bank is not None:
            kp=detect_and_describe(surface,cfg)
            pairs,_=match_descriptors(kp.descriptors,bank['descriptors'],cfg)
            winner=transfer_labels(kp.yx,pairs,bank['labels'],surface.shape[1:],classes,cfg)
            matched=winner>=0
            if matched.any(): score[:,matched]=np.eye(classes,dtype=np.float32)[winner[matched]].T
            diagnostics['keypoints']+=len(kp.yx); diagnostics['matches']+=len(pairs)
        if fallback=='unknown': score[:,~matched]=0
        dense=rasterize(score,ys,xs,tile.shape[:2])
        valid=rasterize((matched if fallback=='unknown' else np.ones_like(matched))[None].astype(float),ys,xs,tile.shape[:2])[0]
        coverage=rasterize(matched[None].astype(float),ys,xs,tile.shape[:2])[0]
        th,tw=tile.shape[:2]; sl=np.s_[y:y+th,x:x+tw]
        # Uniform overlap averaging, including partial edge tiles.
        accum[:,sl[0],sl[1]]+=dense; weight[sl]+=valid
        covered[sl]+=coverage; count[sl]+=1; diagnostics['tiles']+=1
    probs=np.divide(accum,weight[None],out=np.zeros_like(accum),where=weight[None]>1e-8)
    prediction=probs.argmax(0).astype(np.int64); prediction[weight<=1e-8]=-1
    diagnostics['matched_pixel_fraction']=float(np.mean(covered/np.maximum(count,1)))
    diagnostics['unknown_pixel_fraction']=float(np.mean(prediction<0))
    return prediction,probs,diagnostics
