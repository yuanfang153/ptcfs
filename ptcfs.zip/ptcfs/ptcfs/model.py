
from dataclasses import dataclass
import math
import torch
from torch import nn
from torch.nn import functional as F

@dataclass(frozen=True)
class ModelConfig:
    num_classes: int = 10
    patch_size: int = 28
    channels: int = 32
    primary_types: int = 4
    primary_dim: int = 4
    primary_grid: int = 4
    entity_dim: int = 8
    routing_iterations: int = 3
    drop_probability: float = 0.5
    block_size: int = 3
    mode: str = 'stabilized'

    def __post_init__(self):
        for k in ('num_classes','channels','primary_types','primary_dim',
                  'primary_grid','entity_dim','routing_iterations'):
            if getattr(self,k)<1: raise ValueError(f'{k} must be positive')
        if self.patch_size<12: raise ValueError('patch_size must be >=12')
        if self.mode not in ('literal','stabilized'): raise ValueError('invalid mode')
        if not 0<=self.drop_probability<1: raise ValueError('invalid drop_probability')
        if self.block_size<1 or self.block_size%2!=1: raise ValueError('block_size must be positive odd')

def squash(x,eps=1e-8):
   
    n=x.square().sum(-1,keepdim=True)
    return n/(1+n)*x/n.clamp_min(eps).sqrt()

def mcscc(x,y,eps=1e-8):
    
    a,b=x-x.mean(-1,keepdim=True),y-y.mean(-1,keepdim=True)
    den=(a.square().sum(-1)*b.square().sum(-1)).clamp_min(eps).sqrt()
    return ((a*b).sum(-1).abs()/den).clamp(0,1)

def snbscc(x,y,literal=False,eps=1e-8):
    
    dot=(x*y).sum(-1)
    if literal:
        den=x.norm(dim=-1)+y.norm(dim=-1)-dot
        den=torch.where(den.abs()<eps,torch.where(den<0,-eps,eps),den)
    else:
        den=(x.square().sum(-1)+y.square().sum(-1)-dot).clamp_min(eps)
    return dot/den

def coupling(logits,step,mode):
    """Eq. 4 alpha decay uses global optimizer steps, not routing iterations."""
    if step<0: raise ValueError('step must be nonnegative')
    leak=(0.05*0.05**(step//3000))*F.silu(logits)
    if mode=='literal': return leak
    if mode!='stabilized': raise ValueError('invalid mode')
    # Explicit correction: nonzero initial coupling, positive normalization.
    c=(logits.softmax(-1)+leak).clamp_min(1e-8)
    return c/c.sum(-1,keepdim=True)

class EntityRouting(nn.Module):
    def __init__(self,inputs,input_dim,entities,entity_dim,iterations,mode):
        super().__init__()
        self.weight=nn.Parameter(torch.empty(inputs,entities,input_dim,entity_dim))
        nn.init.normal_(self.weight,std=1/math.sqrt(input_dim))
        self.iterations,self.mode=iterations,mode

    def forward(self,primary,phase='compress',step=0):
        if phase not in ('compress','sigmoid'): raise ValueError('invalid phase')
        votes=torch.einsum('bid,ijde->bije',primary,self.weight) # Eq. 2
        logits=votes.new_zeros(votes.shape[:-1])
        for iteration in range(self.iterations):
            s=(coupling(logits,step,self.mode)[...,None]*votes).sum(1) # Eq. 3
            entity=squash(s) if phase=='compress' else s.sigmoid()
            if phase=='sigmoid' and self.mode=='stabilized':
                entity=entity/math.sqrt(entity.shape[-1]) # explicit unit-norm repair
            if iteration+1<self.iterations:
                target=entity[:,None]
                corr=mcscc(votes,target) if phase=='compress' else snbscc(votes,target,self.mode=='literal')
                logits=logits+corr*(votes*target).sum(-1) # Eqs. 5,6
        return entity

class VectorDropBlock(nn.Module):
    
    def __init__(self,probability,block_size):
        super().__init__(); self.probability,self.block_size=probability,block_size
    def forward(self,x):
        if not self.training or self.probability==0: return x
        d=x.shape[-1]; block=min(self.block_size,d if d%2 else max(1,d-1))
        seeds=(torch.rand_like(x)<self.probability/block).to(x.dtype)
        blocked=F.max_pool1d(seeds.flatten(0,1)[:,None],block,1,block//2)
        keep=1-blocked[:,0].reshape_as(x)
        return x*keep*(d/keep.sum(-1,keepdim=True).clamp_min(1))

class Lane(nn.Module):
    def __init__(self,kernel,cfg):
        super().__init__(); self.cfg=cfg
        self.casconv=nn.Sequential(nn.Conv2d(1,cfg.channels,kernel),nn.ReLU())
        self.primary=nn.Conv2d(cfg.channels,cfg.primary_types*cfg.primary_dim,3,2)
        self.routing=EntityRouting(cfg.primary_types*cfg.primary_grid**2,cfg.primary_dim,
                                   cfg.num_classes,cfg.entity_dim,cfg.routing_iterations,cfg.mode)
        self.drop=VectorDropBlock(cfg.drop_probability,cfg.block_size)
        self.decoder=nn.Sequential(nn.Linear(cfg.num_classes*cfg.entity_dim,512),nn.ReLU(),
                                   nn.Linear(512,1024),nn.ReLU(),
                                   nn.Linear(1024,cfg.patch_size**2),nn.Sigmoid())
    def forward(self,x,phase,step,reconstruct):
        cfg=self.cfg
        p=F.adaptive_avg_pool2d(self.primary(self.casconv(x)),cfg.primary_grid)
        p=p.reshape(len(x),cfg.primary_types,cfg.primary_dim,-1)
        p=squash(p.permute(0,1,3,2).reshape(len(x),-1,cfg.primary_dim))
        entity=self.routing(p,phase,step); dropped=self.drop(entity)
        rec=self.decoder(dropped.flatten(1)).reshape_as(x) if reconstruct else None
        return entity,dropped,rec

class PTCFSReference(nn.Module):
    
    def __init__(self,config=None):
        super().__init__(); self.config=config or ModelConfig()
        self.lanes=nn.ModuleList([Lane(k,self.config) for k in (9,7,5)])
    def forward(self,image,phase='compress',step=0,reconstruct=True):
        cfg=self.config
        if image.ndim!=4 or image.shape[1] not in (1,3): raise ValueError('expected [B,1|3,H,W]')
        if not len(image) or tuple(image.shape[-2:])!=(cfg.patch_size,cfg.patch_size):
            raise ValueError(f'expected nonempty {cfg.patch_size}x{cfg.patch_size} patches')
        if not image.is_floating_point() or not torch.isfinite(image).all(): raise ValueError('invalid image values')
        if image.min()<0 or image.max()>1: raise ValueError('images must lie in [0,1]')
        if image.shape[1]==3:
            image=(image*image.new_tensor([.299,.587,.114])[None,:,None,None]).sum(1,keepdim=True)
        out=[lane(image,phase,step,reconstruct) for lane in self.lanes]
        entities=torch.stack([o[0] for o in out],1)
        # Pooling axis unspecified in paper; max over entities gives [B,3,D].
        features=torch.stack([o[1].amax(1) for o in out],1)
        return dict(entities=entities,features=features,scores=entities.norm(dim=-1).mean(1),
                    reconstruction=torch.stack([o[2] for o in out],1) if reconstruct else None,target=image)

def ptcfs_loss(output,labels,reconstruction_weight=.5,negative_weight=.5):
    
    lengths=output['entities'].norm(dim=-1); b,_,classes=lengths.shape
    if labels.shape!=(b,) or labels.dtype!=torch.long: raise ValueError('labels must be [B] int64')
    if (labels<0).any() or (labels>=classes).any(): raise ValueError('label out of range')
    target=F.one_hot(labels,classes)[:,None].to(lengths.dtype)
    margin=(target*F.relu(.9-lengths).square()+negative_weight*(1-target)*F.relu(lengths-.1).square()).sum(-1).mean()
    if output['reconstruction'] is None: raise ValueError('reconstruction required')
    mae=(output['reconstruction']-output['target'][:,None]).abs().mean()
    return dict(loss=margin+reconstruction_weight*mae,margin=margin,mae=mae)
