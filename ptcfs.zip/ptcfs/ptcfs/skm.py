
from dataclasses import dataclass
import numpy as np
from scipy import ndimage as ndi

@dataclass(frozen=True)
class SKMConfig:
    scales: tuple = (1.0, 1.4, 2.0, 2.8, 4.0)
    contrast: float = 0.01
    edge_ratio: float = 10.0
    max_keypoints: int = 256
    min_similarity: float = 0.6
    match_margin: float = 0.05
    region_size: int = 4

    def __post_init__(self):
        if len(self.scales)<3 or any(s<=0 for s in self.scales) or any(a>=b for a,b in zip(self.scales,self.scales[1:])):
            raise ValueError('scales must be strictly increasing positive values, length >=3')
        if not 0<=self.contrast<=1 or self.edge_ratio<=0: raise ValueError('invalid detector thresholds')
        if self.max_keypoints<1 or self.region_size<1: raise ValueError('invalid size')
        if not 0<=self.min_similarity<=1 or not 0<=self.match_margin<=1: raise ValueError('invalid match thresholds')

@dataclass
class Keypoints:
    # Coordinates in feature-lattice pixels, ordered y,x; scale in lattice pixels.
    yx: np.ndarray
    scale: np.ndarray
    response: np.ndarray
    descriptors: np.ndarray

def validate_surface(surface):
    a=np.asarray(surface,dtype=np.float64)
    if a.ndim!=3 or a.shape[0]!=3 or min(a.shape[1:])<1 or not np.isfinite(a).all():
        raise ValueError('surface must be finite [3,H,W]')
    return a

def _sample(a,y,x):
    return ndi.map_coordinates(a,[y,x],order=1,mode='reflect')

def _haar(a,scale):
    
    half=max(1,int(round(scale)))
    box=ndi.uniform_filter(a,size=(2*half,half),mode='reflect')
    box_y=ndi.uniform_filter(a,size=(half,2*half),mode='reflect')
    y,x=np.mgrid[:a.shape[0],:a.shape[1]].astype(float)
    dx=_sample(box,y,x+half/2)-_sample(box,y,x-half/2)
    dy=_sample(box_y,y+half/2,x)-_sample(box_y,y-half/2,x)
    return dx,dy

def _descriptor(surface,y,x,scale):
    responses=[_haar(a,scale) for a in surface]
    # Dominant orientation from a radius-6-scale disk, pi/3 sliding window.
    yy,xx=np.mgrid[-6:7,-6:7]; valid=yy**2+xx**2<=36
    sy,sx=y+yy[valid]*scale,x+xx[valid]*scale
    weight=np.exp(-(yy[valid]**2+xx[valid]**2)/(2*2.5**2))
    dx=sum(_sample(gx,sy,sx) for gx,gy in responses)*weight
    dy=sum(_sample(gy,sy,sx) for gx,gy in responses)*weight
    angle=np.arctan2(dy,dx); best=-1.; orientation=0.
    for center in np.linspace(-np.pi,np.pi,36,endpoint=False):
        take=np.abs(np.angle(np.exp(1j*(angle-center))))<=np.pi/6
        vx,vy=dx[take].sum(),dy[take].sum(); strength=vx*vx+vy*vy
        if strength>best: best,orientation=strength,float(np.arctan2(vy,vx))
    c,s=np.cos(orientation),np.sin(orientation)
    # 4x4 cells, 5x5 samples each, 4 Haar statistics per cell, three lanes.
    yy,xx=np.mgrid[:20,:20].astype(float); yy-=9.5; xx-=9.5
    sy=y+scale*(s*xx+c*yy); sx=x+scale*(c*xx-s*yy)
    gaussian=np.exp(-(xx*xx+yy*yy)/(2*8.0**2))
    values=[]
    for gx,gy in responses:
        a,b=_sample(gx,sy,sx),_sample(gy,sy,sx)
        u,v=(c*a+s*b)*gaussian,(-s*a+c*b)*gaussian
        for iy in range(4):
            for ix in range(4):
                sl=np.s_[iy*5:(iy+1)*5,ix*5:(ix+1)*5]
                values.extend([u[sl].sum(),v[sl].sum(),abs(u[sl]).sum(),abs(v[sl]).sum()])
    raw=np.asarray(values)
    # Explicit nonnegative lifting ensures Tanimoto is in [0,1]; retain magnitude.
    return np.r_[np.maximum(raw,0),np.maximum(-raw,0)].astype(np.float32)

def detect_and_describe(surface,config=None):
    cfg=config or SKMConfig(); surface=validate_surface(surface)
    h,w=surface.shape[1:]; scalar=np.linalg.norm(surface,axis=0)
    if min(h,w)<5 or np.ptp(scalar)<1e-12:
        return Keypoints(np.empty((0,2)),np.empty(0),np.empty(0),np.empty((0,384),np.float32))
    # Remove DC; rescale detection ONLY. Descriptor values retain their amplitudes.
    scalar=(scalar-scalar.mean())/max(scalar.std(),1e-12)
    dets=[]; traces=[]
    for sigma in cfg.scales:
        xx=ndi.gaussian_filter(scalar,sigma,order=(0,2))*sigma**2
        yy=ndi.gaussian_filter(scalar,sigma,order=(2,0))*sigma**2
        xy=ndi.gaussian_filter(scalar,sigma,order=(1,1))*sigma**2
        dets.append(xx*yy-xy*xy); traces.append(xx+yy)
    volume=np.stack(dets); traces=np.stack(traces)
    maxima=ndi.maximum_filter(volume,size=(3,3,3),mode='constant',cval=-np.inf)
    keep=(volume==maxima)&(volume>max(1e-12,cfg.contrast*volume.max()))
    # Positive determinant and bounded trace^2/det reject saddles and edge ridges.
    keep &= traces**2/np.maximum(volume,1e-12)<(cfg.edge_ratio+1)**2/cfg.edge_ratio
    keep[[0,-1]]=False; keep[:,:1]=False; keep[:,-1:]=False
    keep[:,:,:1]=False; keep[:,:,-1:]=False
    coords=np.argwhere(keep)
    if len(coords):
        scores=volume[tuple(coords.T)]
        coords=coords[np.argsort(-scores,kind='stable')[:cfg.max_keypoints]]
    points=[]; scales=[]; strengths=[]; descriptors=[]
    for k,y,x in coords:
        # Quadratic interpolation jointly in scale index, y, x.
        q=np.array([k,y,x]); grad=np.zeros(3); hes=np.zeros((3,3)); f=volume[k,y,x]
        for a in range(3):
            ea=np.eye(3,dtype=int)[a]
            grad[a]=(volume[tuple(q+ea)]-volume[tuple(q-ea)])/2
            hes[a,a]=volume[tuple(q+ea)]-2*f+volume[tuple(q-ea)]
            for b in range(a):
                eb=np.eye(3,dtype=int)[b]
                hes[a,b]=hes[b,a]=(volume[tuple(q+ea+eb)]-volume[tuple(q+ea-eb)]-volume[tuple(q-ea+eb)]+volume[tuple(q-ea-eb)])/4
        try: offset=-np.linalg.solve(hes,grad)
        except np.linalg.LinAlgError: continue
        if not np.isfinite(offset).all() or np.max(abs(offset))>.5: continue
        scale=float(np.exp(np.interp(k+offset[0],np.arange(len(cfg.scales)),np.log(cfg.scales))))
        py,px=y+offset[1],x+offset[2]
        # Full rotated 20-scale square must fit; no fabricated boundary samples.
        border=15*scale
        if min(py,px,h-1-py,w-1-px)<border: continue
        descriptor=_descriptor(surface,py,px,scale)
        if np.linalg.norm(descriptor)<1e-12: continue
        points.append([py,px]); scales.append(scale); strengths.append(f); descriptors.append(descriptor)
    return Keypoints(np.asarray(points).reshape(-1,2),np.asarray(scales),np.asarray(strengths),
                     np.asarray(descriptors,dtype=np.float32).reshape(-1,384))

def tanimoto_matrix(a,b):
    a=np.asarray(a,dtype=np.float64); b=np.asarray(b,dtype=np.float64)
    if a.ndim!=2 or b.ndim!=2 or a.shape[1]!=b.shape[1]: raise ValueError('descriptor shape mismatch')
    if not np.isfinite(a).all() or not np.isfinite(b).all() or (a<0).any() or (b<0).any():
        raise ValueError('SKM descriptors must be finite and nonnegative')
    dot=a@b.T; den=(a*a).sum(1)[:,None]+(b*b).sum(1)[None,:]-dot
    return np.divide(dot,den,out=np.zeros_like(dot),where=den>1e-12).clip(0,1)

def match_descriptors(query,reference,config=None,chunk_size=4096):
    
    cfg=config or SKMConfig()
    query=np.asarray(query,dtype=float); reference=np.asarray(reference,dtype=float)
    # Validate even empty inputs without allocating the full affinity matrix.
    tanimoto_matrix(query[:0],reference[:0])
    if not np.isfinite(query).all() or not np.isfinite(reference).all() or (query<0).any() or (reference<0).any():
        raise ValueError('invalid descriptors')
    if chunk_size<1: raise ValueError('chunk_size must be positive')
    nq,nr=len(query),len(reference)
    if not nq or not nr: return np.empty((0,2),int),np.empty(0)
    best=np.full(nq,-np.inf); second=np.full(nq,-np.inf); best_index=np.zeros(nq,int)
    reverse=np.empty(nr,int)
    for start in range(0,nr,chunk_size):
        sims=tanimoto_matrix(query,reference[start:start+chunk_size])
        local_index=sims.argmax(1); first=sims[np.arange(nq),local_index]
        runner=np.partition(sims,-2,axis=1)[:,-2] if sims.shape[1]>1 else np.full(nq,-np.inf)
        better=first>best
        second=np.maximum(np.maximum(second,runner),np.where(better,best,first))
        best_index=np.where(better,start+local_index,best_index)
        best=np.maximum(best,first)
        reverse[start:start+sims.shape[1]]=sims.argmax(0)
    if nr==1: second[:]=0
    take=(best>=cfg.min_similarity)&(best-second>=cfg.match_margin)
    take &= reverse[best_index]==np.arange(nq)
    ix=np.flatnonzero(take)
    return np.c_[ix,best_index[ix]],best[ix]

def transfer_labels(points,matches,reference_labels,shape,num_classes,config=None):
   
    cfg=config or SKMConfig(); h,w=shape; size=cfg.region_size
    counts=np.zeros(((h+size-1)//size,(w+size-1)//size,num_classes),np.int64)
    labels=np.asarray(reference_labels)
    for qi,ri in matches:
        label=int(labels[ri])
        if label<0 or label>=num_classes: raise ValueError('reference label out of range')
        y,x=np.floor(points[qi]).astype(int)
        if not (0<=y<h and 0<=x<w): raise ValueError('query point outside surface')
        counts[y//size,x//size,label]+=1
    win=counts.argmax(-1); maximum=counts.max(-1)
    win[(maximum==0)|((counts==maximum[...,None]).sum(-1)>1)]=-1
    return np.repeat(np.repeat(win,size,0),size,1)[:h,:w]
