import json
from dataclasses import asdict
import numpy as np
import pytest
import torch
from ptcfs.model import ModelConfig,PTCFSReference,EntityRouting,coupling,squash,mcscc,snbscc,ptcfs_loss
from ptcfs.data import confusion_matrix,metric_report,crop_patch,read_manifest,read_mask
from ptcfs.pipeline import tile_starts,rasterize,dense_features,predict_image,model_fingerprint,load_bank,bank_metadata
from ptcfs.skm import SKMConfig,detect_and_describe,tanimoto_matrix,match_descriptors,transfer_labels
from ptcfs.cli import load_checkpoint
from PIL import Image

torch.set_num_threads(2)

@pytest.fixture
def small():
    torch.manual_seed(4)
    return PTCFSReference(ModelConfig(num_classes=3,channels=4,primary_types=2,primary_dim=3,primary_grid=2,entity_dim=4,drop_probability=0))

def test_equation4_exposes_dead_initialization():
    logits=torch.zeros(2,5,3)
    assert torch.count_nonzero(coupling(logits,0,'literal'))==0
    assert torch.allclose(coupling(logits,0,'stabilized'),torch.full_like(logits,1/3))
    route=EntityRouting(5,3,2,4,3,'literal')
    assert torch.count_nonzero(route(torch.randn(2,5,3),'compress'))==0

def test_leak_schedule():
    b=torch.tensor([1.])
    assert torch.allclose(coupling(b,3000,'literal'),coupling(b,0,'literal')*.05)

def test_correlations():
    x=torch.tensor([[1.,2.,3.],[3.,3.,3.]])
    assert torch.allclose(mcscc(x,x),torch.tensor([1.,0.]))
    assert mcscc(x[:1],-x[:1]).item()==pytest.approx(1.)
    assert torch.allclose(snbscc(x,x),torch.ones(2))
    v=torch.tensor([[3.,0.]])
    assert snbscc(v,v,True).item()==pytest.approx(-3.) # printed formula not [0,1]
    assert snbscc(torch.zeros_like(v),torch.zeros_like(v)).item()==0

def test_squash_zero_and_gradient():
    x=torch.zeros(3,4,requires_grad=True); squash(x).sum().backward()
    assert torch.isfinite(x.grad).all()
    assert squash(torch.randn(10,4)*100).norm(dim=-1).max()<1.000001

@pytest.mark.parametrize('phase',['compress','sigmoid'])
def test_shapes_and_all_lanes_receive_gradients(small,phase):
    x=torch.rand(3,3,28,28); out=small(x,phase)
    assert out['entities'].shape==(3,3,3,4)
    assert out['features'].shape==(3,3,4)
    assert out['reconstruction'].shape==(3,3,1,28,28)
    assert out['entities'].norm(dim=-1).max()<=1.000001
    loss=ptcfs_loss(out,torch.tensor([0,1,2]))['loss']; loss.backward()
    for lane in small.lanes:
        for p in [lane.casconv[0].weight,lane.primary.weight,lane.routing.weight,lane.decoder[0].weight]:
            assert p.grad is not None and torch.isfinite(p.grad).all() and p.grad.abs().sum()>0

def test_literal_sigmoid_not_unit_norm():
    route=EntityRouting(2,3,2,8,1,'literal')
    out=route(torch.randn(1,2,3),'sigmoid')
    assert out.norm(dim=-1).min()>1

def test_training_reduces_loss(small):
    x=torch.rand(6,3,28,28); y=torch.tensor([0,1,2,0,1,2])
    opt=torch.optim.AdamW(small.parameters(),lr=.003)
    initial=float(ptcfs_loss(small(x),y)['loss'].detach())
    for _ in range(16):
        opt.zero_grad(); loss=ptcfs_loss(small(x),y)['loss']; loss.backward(); opt.step()
    final=float(ptcfs_loss(small(x),y)['loss'].detach())
    assert final<initial*.8

def test_checkpoint_roundtrip(small,tmp_path):
    small.eval(); x=torch.rand(1,3,28,28)
    file=tmp_path/'model.pt'
    torch.save(dict(format=1,config=asdict(small.config),model=small.state_dict()),file)
    loaded,_=load_checkpoint(file,'cpu')
    assert torch.equal(small(x)['scores'],loaded(x)['scores'])
    assert model_fingerprint(small)==model_fingerprint(loaded)

@pytest.mark.parametrize('length',[1,511,512,513,896,1025])
def test_tile_coverage(length):
    hits=np.zeros(length)
    for start in tile_starts(length): hits[start:start+512]+=1
    assert hits.min()>0
    assert len(tile_starts(length))==len(set(tile_starts(length)))

def test_crop_center_alignment():
    a=np.arange(5*7*3).reshape(5,7,3)
    for size in [27,28]:
        for y,x in [(0,0),(2,3),(4,6)]:
            p=crop_patch(a,y,x,size)
            assert p.shape==(size,size,3)
            np.testing.assert_array_equal(p[size//2,size//2],a[y,x])

def test_rasterize_nonuniform_grid():
    ys=np.array([0,2,5]); xs=np.array([0,3,4])
    array=ys[:,None]+2*xs[None,:]
    out=rasterize(array[None],ys,xs,(6,5))[0]
    np.testing.assert_allclose(out,np.arange(6)[:,None]+2*np.arange(5)[None,:],atol=1e-6)

def test_dense_prediction_arbitrary_size(small):
    image=np.random.default_rng(5).random((31,37,3),dtype=np.float32)
    small.train(); pred,score,info=predict_image(small,image,stride=8,batch_size=8,tile_size=23,overlap=7)
    assert small.training
    assert pred.shape==(31,37) and score.shape==(3,31,37)
    np.testing.assert_allclose(score.sum(0),1,atol=1e-6)
    assert info['drfe_only'] and info['matches']==0
    unknown,_,_=predict_image(small,image,stride=16,fallback='unknown')
    assert np.all(unknown==-1)

def test_metrics_foreground_not_macro():
    cm=np.array([[8,1,0],[0,2,3],[1,4,1]])
    result=metric_report(cm)
    assert result['foreground_f1']==pytest.approx(20/22)
    assert result['foreground_f1']!=pytest.approx(result['macro_f1'])
    true=np.array([0,1,255]); pred=np.array([0,2,255])
    assert confusion_matrix(true,pred,3).sum()==2
    with pytest.raises(ValueError): confusion_matrix(np.array([1]),np.array([255]),3)

def test_descriptor_matching_and_ambiguity():
    desc=np.eye(3)
    np.testing.assert_allclose(tanimoto_matrix(desc,desc),np.eye(3))
    pairs,scores=match_descriptors(desc,desc)
    np.testing.assert_array_equal(pairs,np.c_[np.arange(3),np.arange(3)])
    assert np.all(scores==1)
    pairs,_=match_descriptors(desc[:1],np.repeat(desc[:1],2,axis=0))
    assert len(pairs)==0
    pairs,_=match_descriptors(np.empty((0,3)),desc)
    assert pairs.shape==(0,2)
    assert tanimoto_matrix(np.zeros((1,3)),np.zeros((1,3)))[0,0]==0

def test_region_voting_tie_and_unknown():
    pts=np.array([[1,1],[2,2],[1,6]])
    pairs=np.array([[0,0],[1,1],[2,2]])
    out=transfer_labels(pts,pairs,np.array([1,2,2]),(8,8),3)
    assert np.all(out[:4,:4]==-1) and np.all(out[:4,4:]==2) and np.all(out[4:]==-1)

def blob_surface():
    y,x=np.mgrid[:128,:128]
    a=np.exp(-((y-48)**2+(x-45)**2)/(2*2.0**2))
    b=.7*np.exp(-((y-76)**2+(x-78)**2)/(2*2.8**2))
    return np.stack([a+b,.8*a+1.2*b,1.1*a+.6*b])

def test_detector_real_keypoints_and_self_matches():
    a=blob_surface(); kp=detect_and_describe(a)
    assert len(kp.yx)>=1
    assert kp.descriptors.shape[1]==384 and np.isfinite(kp.descriptors).all()
    pairs,scores=match_descriptors(kp.descriptors,kp.descriptors)
    assert len(pairs)>=1 and scores.min()>.999
    empty=detect_and_describe(np.zeros((3,64,64)))
    assert empty.descriptors.shape==(0,384)

def test_detector_translation():
    kp=detect_and_describe(blob_surface()); shifted=detect_and_describe(np.roll(blob_surface(),3,axis=2))
    pairs,_=match_descriptors(kp.descriptors,shifted.descriptors)
    assert len(pairs)>=1
    np.testing.assert_allclose(shifted.yx[pairs[:,1]]-kp.yx[pairs[:,0]],np.tile([0,3],(len(pairs),1)),atol=.2)

def test_bank_config_mismatch_rejected(small,tmp_path):
    metadata=bank_metadata(small,4,'sigmoid',0,SKMConfig())
    path=tmp_path/'bank.npz'
    np.savez(path,descriptors=np.ones((1,384)),labels=np.array([1]),metadata=json.dumps(metadata))
    bank=load_bank(path,small,4,'sigmoid',0); assert bank['labels'][0]==1
    with pytest.raises(ValueError,match='stride'): load_bank(path,small,8,'sigmoid',0)

def test_bad_inputs(small,tmp_path):
    with pytest.raises(ValueError): small(torch.zeros(1,3,30,30))
    with pytest.raises(ValueError): small(torch.full((1,3,28,28),float('nan')))
    with pytest.raises(ValueError): small(torch.ones(1,3,28,28)*255)
    with pytest.raises(ValueError): ModelConfig(drop_probability=1)
    with pytest.raises(ValueError): SKMConfig(scales=(2,1,3))
    with pytest.raises(ValueError): tanimoto_matrix(-np.ones((1,3)),np.ones((1,3)))
    file=tmp_path/'mask.png'; Image.fromarray(np.array([[14]],np.uint8)).save(file)
    with pytest.raises(ValueError): read_mask(file,(1,1),3)

def test_chunked_matches_equal_dense():
    rng=np.random.default_rng(8); query=rng.random((8,384)); reference=rng.random((17,384))
    reference[9:17]=query
    expected,score=match_descriptors(query,reference,chunk_size=100)
    got,other=match_descriptors(query,reference,chunk_size=3)
    np.testing.assert_array_equal(got,expected); np.testing.assert_allclose(other,score)

def test_real_drfe_to_skm_bank(small,tmp_path):
    from ptcfs.pipeline import build_bank
    from ptcfs.data import read_image
    y,x=np.mgrid[:128,:128]
    a=.2+.5*np.exp(-((x-50)**2+(y-55)**2)/90)+.2*np.sin(x/5)*np.cos(y/7)
    image=np.stack([a,np.roll(a,5,0),np.roll(a,4,1)],-1).clip(0,1)
    ip=tmp_path/'reference.png'; mp=tmp_path/'labels.png'; bp=tmp_path/'bank.npz'
    Image.fromarray(np.rint(image*255).astype(np.uint8)).save(ip)
    Image.fromarray((x>64).astype(np.uint8)).save(mp)
    cfg=SKMConfig(contrast=.001)
    built=build_bank(small,[dict(image=ip,mask=mp)],bp,stride=1,batch_size=128,config=cfg)
    bank=load_bank(bp,small,1,'sigmoid',0,cfg)
    prediction,scores,info=predict_image(small,read_image(ip),bank,stride=1,batch_size=128,config=cfg)
    assert built['descriptors']>0 and info['matches']>0
    assert info['matched_pixel_fraction']>0 and not info['drfe_only']
    assert prediction.shape==(128,128) and np.isfinite(scores).all()
